<section class="content-header">
    <h1>Backup DB<small>Version 2.0</small></h1>
    <ol class="breadcrumb">
        <li><a href="?act=home"><i class="fa fa-dashboard"></i> AdminCP</a></li>
        <li class="active">Backup DB</li>
    </ol>
</section><!--/. content-header-->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box-common box-danger">
                <div class="box-header with-border">
                    <h3 class="box-title">Backup cơ sở dữ liệu</h3>
                    <div class="box-tools pull-right">
                        <span class="function">
                            <a href="?act=backup">Backup</a>
                        </span>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="paddinglr10">
                <iframe width="100%" height="300" src="../cron/dbBackup.php" frameborder="0"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>