<?php
setlocale(LC_ALL, 'UTF8');

/*
	TNB-PHP
	@author - Tran Nhat Bao
	@All rights reserved
	Support by	:	_
	Edited by	:	_
*/

//	Common - class
	include	"common.php";
	include "system.class.php";
//	C
	include "curl.class.php";
//	D
	include	"date.class.php";
//	F
	include "file.class.php";
//	N
	include	"number.class.php";
//	M
	include	"mysql.class.php";
	include "mssql.class.php";
	include "mail.class.php";
//	P
	include	"printer.class.php";
//	R
	include "rss.class.php";
//	S
	include	"string.class.php";
//	File - struct
	include	"_file/rar_file.class.php";
	include	"_file/zip_file.class.php";
?>