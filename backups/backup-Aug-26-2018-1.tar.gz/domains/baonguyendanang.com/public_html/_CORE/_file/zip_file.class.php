<?
class	zip_file
{
	var		$src;
	public	function	__construct()
	{
		
	}
	public	function	__destruct()
	{
		
	}
}
?>