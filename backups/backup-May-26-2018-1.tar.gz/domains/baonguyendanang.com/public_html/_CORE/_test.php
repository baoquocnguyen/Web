<?
	include "index.php";
	$mail=new lg_mail();
	//$mail->subject	=	"12312312";
	//$mail->message	=	"Noi dung";
	$mail->send();
?>