<div id="content--content">
    <div class="container">
<div class="margin-top30 other_box" style="padding-top: 30px;padding-bottom: 30px;">
    <div class="row">
    <div class="col-md-12 col-sm-12 content_right bottom">
        <h1 class="content-title"><?=the_title?></h1>
        <div class="noi_dung">
            <?=the_content?>
        </div>
    </div>
    </div>
</div>
</div>
</div>