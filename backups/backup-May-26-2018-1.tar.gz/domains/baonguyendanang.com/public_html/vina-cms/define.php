<?php
define("admin_company", "VinaDesign");
define("admin_url", "vina-cms");
define("admin_name", "Long Cao");
define("admin_phone", "0943 426 600");
define("admin_email", "long.danang@vinadesign.vn");
?>