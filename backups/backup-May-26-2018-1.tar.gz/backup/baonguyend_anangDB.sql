-- MySQL dump 10.13  Distrib 5.5.31, for Linux (x86_64)
--
-- Host: localhost    Database: baonguyend_anangDB
-- ------------------------------------------------------
-- Server version	5.5.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `donhang`
--

DROP TABLE IF EXISTS `donhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donhang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `diachi` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `yeu_cau` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `tien` int(11) NOT NULL,
  `congty` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ma` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `thanh_toan` varchar(255) NOT NULL,
  `custom_id` int(11) NOT NULL,
  `cod` varchar(10) NOT NULL,
  `activate` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donhang`
--

LOCK TABLES `donhang` WRITE;
/*!40000 ALTER TABLE `donhang` DISABLE KEYS */;
INSERT INTO `donhang` VALUES (7,'longcao','Ä‘Ã  náºµng','0943426600','longcaodn@gmail.com','tui muá»‘n mua sp nÃ y, cáº§n tÆ° váº¥n thÃªm...','<table width=\"100%\" cellpadding=\"3\" cellspacing=\"3\" class=\"table table-hover table-condensed\" ><tr><th>TÃªn sáº£n pháº©m</th><th>GiÃ¡</th><th>Sá»‘ lÆ°á»£ng</th><th>ThÃ nh tiá»n</th></tr><tr><td>DAO SPA MAMA - XÃ”NG Táº®M CHO PHá»¤ Ná»® SAU SINH</td><td>320.000 <sup>Ä‘/sp</sup></td><td>1 </td><td>320.000 <sup>Ä‘</sup></td></tr><tr><td colspan=\"3\"><b>Tá»•ng cá»™ng </b><br /></td><td><b style=\"font-weight: bold; font-size: 15px; color: #ff0000;\">320.000 <sup>Ä‘</sup></b></td></tr></table>',1522227991,0,320000,'vinadesign',NULL,'Thanh toÃ¡n báº±ng hÃ¬nh thá»©c chuyá»ƒn khoáº£n',0,'',0);
/*!40000 ALTER TABLE `donhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `display` int(1) NOT NULL DEFAULT '1',
  `thu_tu` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES (1,'Viá»‡t Nam','vn',1,1),(10,'English','en',1,2);
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lienhe`
--

DROP TABLE IF EXISTS `lienhe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lienhe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tieu_de` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `view` int(1) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `khoa_hoc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lienhe`
--

LOCK TABLES `lienhe` WRITE;
/*!40000 ALTER TABLE `lienhe` DISABLE KEYS */;
/*!40000 ALTER TABLE `lienhe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_file`
--

DROP TABLE IF EXISTS `media_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dir_folder` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `mine` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_file`
--

LOCK TABLES `media_file` WRITE;
/*!40000 ALTER TABLE `media_file` DISABLE KEYS */;
INSERT INTO `media_file` VALUES (6,'bg_info','12-2017','bg_info.jpg','259826','jpg','image','2017-12-07 02:39:44'),(7,'9-banner-trang-gioi-thieu','12-2017','9-banner-trang-gioi-thieu.jpg','133663','jpg','image','2017-12-08 04:31:12'),(8,'Office-Interior-Design-1024x677','12-2017','office-interior-design-1024x677.jpg','111124','jpg','image','2017-12-08 08:09:10'),(9,'Office-interior-design-in-hyderabad','12-2017','office-interior-design-in-hyderabad.jpg','472162','jpg','image','2017-12-08 08:09:44'),(10,'plaster ceiling (1)','12-2017','plaster-ceiling-(1).jpg','247054','jpg','image','2017-12-08 08:09:44'),(11,'tran thach cao dep_van phong-01','12-2017','tran-thach-cao-dep_van-phong-01.jpg','91951','jpg','image','2017-12-08 08:09:44'),(46,'1708','03-2018','1708.jpg','703141','jpg','image','2018-03-09 08:06:30'),(55,'17089','03-2018','17089.jpg','505165','jpg','image','2018-03-22 13:27:39'),(56,'Beach-Umbrella','03-2018','beach-umbrella.jpg','377822','jpg','image','2018-03-22 13:41:31'),(57,'Family-Beaches','03-2018','family-beaches.jpg','328325','jpg','image','2018-03-22 13:43:22'),(58,'tam-trang-da-tu-nhien-mau-don-1-1','03-2018','tam-trang-da-tu-nhien-mau-don-1-1.jpg','84323','jpg','image','2018-03-26 05:21:49'),(59,'tam-trang-da-tu-nhien-mau-don-2','03-2018','tam-trang-da-tu-nhien-mau-don-2.jpg','111095','jpg','image','2018-03-26 05:25:35'),(60,'tam-trang-da-tu-nhien-mau-don-3','03-2018','tam-trang-da-tu-nhien-mau-don-3.jpg','87500','jpg','image','2018-03-26 05:25:36'),(61,'tam-trang-da-tu-nhien-mau-don-4','03-2018','tam-trang-da-tu-nhien-mau-don-4.jpg','74157','jpg','image','2018-03-26 05:25:36'),(62,'bot-dap-mat-thanh-moc-huong234234-2-copy_2-420x512','03-2018','bot-dap-mat-thanh-moc-huong234234-2-copy_2-420x512.jpg','42114','jpg','image','2018-03-26 05:31:57'),(63,'19029211_728231210690651_2577891667841836717_n-320x512','03-2018','19029211_728231210690651_2577891667841836717_n-320x512.jpg','30658','jpg','image','2018-03-26 05:32:38'),(64,'20294018_1978707532365095_8108427825334517920_n-420x512','03-2018','20294018_1978707532365095_8108427825334517920_n-420x512.jpg','46039','jpg','image','2018-03-26 05:32:38'),(66,'bot-dap-mat-thanh-moc-huong234234-2-copy_2-420x512','03-2018','bot-dap-mat-thanh-moc-huong234234-2-copy_2-420x512-66.jpg','42114','jpg','image','2018-03-26 05:32:39'),(67,'IMG_20170507_094638-420x512','03-2018','img_20170507_094638-420x512.jpg','48171','jpg','image','2018-03-26 05:32:39'),(80,'Elemis-400X400','03-2018','elemis-400x400.jpg','94518','jpg','image','2018-03-28 08:17:13'),(81,'timthumb.php','03-2018','timthumbphp.jpg','45950','jpg','image','2018-03-28 08:30:59'),(82,'tinh-dau','03-2018','tinh-dau.jpg','282705','jpg','image','2018-03-28 08:31:47'),(83,'tinh-dau-spa-cho-phu-nu-sau-sinh','03-2018','tinh-dau-spa-cho-phu-nu-sau-sinh.jpg','157680','jpg','image','2018-03-28 08:31:47'),(84,'tinh-dau-spa-mama','03-2018','tinh-dau-spa-mama.jpg','211778','jpg','image','2018-03-28 08:31:47'),(85,'leu-xong-hoi-lxh01x-2-700x700','03-2018','leu-xong-hoi-lxh01x-2-700x700.jpg','206235','jpg','image','2018-03-28 08:54:04'),(86,'213471_kenzo','05-2018','213471_kenzo.jpg','11442','jpg','image','2018-05-13 22:02:47'),(88,'20732925_1478014118925052_99907482_n','05-2018','20732925_1478014118925052_99907482_n.jpg','96369','jpg','image','2018-05-16 21:19:46'),(89,'20733054_1478014232258374_949982977_n','05-2018','20733054_1478014232258374_949982977_n.jpg','45447','jpg','image','2018-05-16 21:19:54'),(90,'20751615_1478014555591675_2110468902_n','05-2018','20751615_1478014555591675_2110468902_n.jpg','59601','jpg','image','2018-05-16 21:20:09'),(91,'20621128_2024323914466072_3280128415529343311_n','05-2018','20621128_2024323914466072_3280128415529343311_n.jpg','52196','jpg','image','2018-05-16 21:25:05'),(92,'20637853_2024323921132738_6109781981376030863_n','05-2018','20637853_2024323921132738_6109781981376030863_n.jpg','54944','jpg','image','2018-05-16 21:25:11'),(93,'20707534_1478026872257110_1632657645_n','05-2018','20707534_1478026872257110_1632657645_n.jpg','35340','jpg','image','2018-05-16 21:25:17'),(94,'20707780_1478014005591730_1780818368_n','05-2018','20707780_1478014005591730_1780818368_n.jpg','14420','jpg','image','2018-05-16 21:25:23'),(96,'20750751_1478014452258352_713344175_n','05-2018','20750751_1478014452258352_713344175_n.jpg','55551','jpg','image','2018-05-16 21:25:35'),(97,'20751467_1478027345590396_1259976098_n','05-2018','20751467_1478027345590396_1259976098_n.jpg','100460','jpg','image','2018-05-16 21:28:22'),(98,'1','05-2018','1.jpg','2445461','jpg','image','2018-05-16 21:35:41'),(99,'2','05-2018','2.jpg','2146806','jpg','image','2018-05-16 21:36:31'),(100,'3','05-2018','3.jpg','2423573','jpg','image','2018-05-16 21:37:13');
/*!40000 ALTER TABLE `media_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_relationship`
--

DROP TABLE IF EXISTS `media_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_relationship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `media_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `parent_type` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `thu_tu` int(11) NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_relationship`
--

LOCK TABLES `media_relationship` WRITE;
/*!40000 ALTER TABLE `media_relationship` DISABLE KEYS */;
INSERT INTO `media_relationship` VALUES (16,57,2,'info','avatar','','','',1,0,0,'2017-12-07 02:41:24'),(18,7,11,'post','avatar','','','',1,0,0,'2017-12-08 04:32:14'),(19,7,12,'post','avatar','','','',1,0,0,'2017-12-08 04:41:43'),(20,7,13,'post','avatar','','','',1,0,0,'2017-12-08 07:36:29'),(21,7,14,'post','avatar','','','',1,0,0,'2017-12-08 07:41:33'),(22,8,15,'post','avatar','','','',1,0,0,'2017-12-08 08:09:19'),(23,9,16,'post','avatar','','','',1,0,0,'2017-12-08 08:09:51'),(24,10,17,'post','avatar','','','',1,0,0,'2017-12-08 08:10:05'),(25,11,18,'post','avatar','','','',1,0,0,'2017-12-08 08:10:22'),(26,7,19,'post','avatar','','','',1,0,0,'2017-12-08 08:16:11'),(58,7,28,'post','avatar','','','',1,0,0,'2017-12-12 03:04:39'),(59,7,29,'post','avatar','','','',1,0,0,'2017-12-12 03:55:43'),(60,7,8,'postcat','avatar','','','',1,0,0,'2018-03-06 04:08:55'),(105,55,1,'gallery','gallery','17089','','',1,0,0,'2018-03-22 13:32:06'),(106,46,1,'gallery','gallery','1708','','',1,0,0,'2018-03-22 13:32:06'),(107,56,1,'gallery','gallery','Beach-Umbrella','','',1,0,0,'2018-03-22 13:41:38'),(108,57,1,'gallery','gallery','Family-Beaches','','',1,0,0,'2018-03-22 13:43:24'),(135,80,60,'post','avatar','','','',1,0,0,'2018-03-28 08:17:21'),(136,81,61,'post','avatar','','','',1,0,0,'2018-03-28 08:31:10'),(137,82,61,'post','album','tinh-dau','','',1,0,0,'2018-03-28 08:32:33'),(138,83,61,'post','album','tinh-dau-spa-cho-phu-nu-sau-sinh','','',1,0,0,'2018-03-28 08:32:33'),(139,84,61,'post','album','tinh-dau-spa-mama','','',1,0,0,'2018-03-28 08:32:33'),(140,84,7,'member','avatar','','','',1,0,0,'2018-03-28 08:42:32'),(141,46,4,'member','avatar','','','',1,0,0,'2018-03-28 08:42:54'),(142,85,62,'post','avatar','','','',1,0,0,'2018-03-28 08:54:14'),(145,88,63,'post','avatar','','','',1,0,0,'2018-05-16 21:20:24'),(146,89,64,'post','avatar','','','',1,0,0,'2018-05-16 21:21:57'),(147,90,65,'post','avatar','','','',1,0,0,'2018-05-16 21:23:31'),(148,96,66,'post','avatar','','','',1,0,0,'2018-05-16 21:25:55'),(149,92,67,'post','avatar','','','',1,0,0,'2018-05-16 21:27:31'),(150,91,68,'post','avatar','','','',1,0,0,'2018-05-16 21:28:48'),(151,97,69,'post','avatar','','','',1,0,0,'2018-05-16 21:29:15'),(152,98,70,'post','avatar','','','',1,0,0,'2018-05-16 21:36:08'),(153,99,71,'post','avatar','','','',1,0,0,'2018-05-16 21:37:07'),(154,100,72,'post','avatar','','','',1,0,0,'2018-05-16 21:37:50');
/*!40000 ALTER TABLE `media_relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `cat1` int(11) NOT NULL,
  `cat2` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `user` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `luot_xem` int(11) NOT NULL,
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `post_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time_edit` int(11) NOT NULL,
  `user_edit` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `option1` int(1) NOT NULL DEFAULT '0',
  `option2` int(1) NOT NULL DEFAULT '0',
  `thu_tu` int(11) NOT NULL,
  `file` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file_size` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dir_file` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (11,7,0,0,1,1512707534,'5',0,0,'other_detail',1512707534,'5',0,0,0,'','',''),(12,7,0,0,1,1512708103,'5',0,0,'other_detail',1512708103,'5',0,0,0,'','',''),(13,7,0,0,1,1512718462,'5',0,0,'other_detail',1512718589,'5',0,0,0,'','',''),(14,7,0,0,1,1512718893,'5',0,0,'other_detail',1512718893,'5',0,0,0,'','',''),(15,30,8,0,1,1512720559,'5',0,0,'post_detail',1520309447,'5',0,0,0,'','',''),(16,29,8,0,1,1512720591,'5',0,0,'post_detail',1526507469,'7',0,0,0,'','',''),(17,29,8,0,1,1512720605,'5',0,0,'post_detail',1526507247,'7',0,0,0,'','',''),(18,29,8,0,1,1512720622,'5',0,0,'post_detail',1526507197,'7',0,0,0,'','',''),(19,7,0,0,1,1512720971,'5',0,0,'other_detail',1512720971,'5',0,0,0,'','',''),(28,7,0,0,1,1513047879,'5',0,0,'other_detail',1513047879,'5',0,0,0,'','',''),(29,7,0,0,1,1513050943,'5',0,0,'other_detail',1513050943,'5',0,0,0,'','',''),(61,38,31,0,1,1522225596,'4',12,1,'catproduct_detail',1522226190,'4',0,0,0,'','',''),(62,47,31,0,1,1522227254,'7',6,1,'catproduct_detail',1522227254,'7',0,0,0,'','',''),(60,45,28,0,1,1522225041,'4',11,1,'catproduct_detail',1522225279,'4',0,0,0,'','',''),(58,29,8,0,0,1521625959,'4',0,0,'post_detail',1526507293,'7',0,0,0,'','',''),(63,48,0,0,1,1526505382,'7',4,0,'catproduct_detail',1526505725,'7',0,0,0,'','',''),(64,48,0,0,1,1526505717,'7',1,0,'catproduct_detail',1526505717,'7',0,0,0,'','',''),(65,48,0,0,1,1526505811,'7',1,0,'catproduct_detail',1526505879,'7',0,0,0,'','',''),(66,48,0,0,1,1526505955,'7',1,0,'catproduct_detail',1526505999,'7',0,0,0,'','',''),(67,48,0,0,1,1526506051,'7',1,0,'catproduct_detail',1526506292,'7',0,0,0,'','',''),(68,48,0,0,1,1526506128,'7',1,0,'catproduct_detail',1526506270,'7',0,0,0,'','',''),(69,48,0,0,1,1526506155,'7',1,0,'catproduct_detail',1526506225,'7',0,0,0,'','',''),(70,48,0,0,1,1526506568,'7',2,0,'catproduct_detail',1526506568,'7',0,0,0,'','',''),(71,48,0,0,1,1526506627,'7',1,0,'catproduct_detail',1526506627,'7',0,0,0,'','',''),(72,48,0,0,1,1526506670,'7',1,0,'catproduct_detail',1526506670,'7',0,0,0,'','','');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_album`
--

DROP TABLE IF EXISTS `post_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `catalog` int(11) NOT NULL,
  `ten` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hinh` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'no',
  `time` int(11) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(11) NOT NULL,
  `dir` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_album`
--

LOCK TABLES `post_album` WRITE;
/*!40000 ALTER TABLE `post_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_album_menu`
--

DROP TABLE IF EXISTS `post_album_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_album_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `sp_id` int(11) NOT NULL,
  `hinh` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_thich` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `post_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dir` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_album_menu`
--

LOCK TABLES `post_album_menu` WRITE;
/*!40000 ALTER TABLE `post_album_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_album_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_lang`
--

DROP TABLE IF EXISTS `post_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `lang_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ten_kd` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_thich` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_thich_kd` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung_kd` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title_seo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `old_price` varchar(255) NOT NULL,
  `new_price` varchar(255) NOT NULL,
  `wholesale_price` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_lang`
--

LOCK TABLES `post_lang` WRITE;
/*!40000 ALTER TABLE `post_lang` DISABLE KEYS */;
INSERT INTO `post_lang` VALUES (28,28,'vn','Banner trang giá» hÃ ng','Banner trang gio hang','','','','','','banner-trang-gio-hang.html','','','','',''),(29,29,'vn','Banner trang Ä‘áº·t hÃ ng','Banner trang dat hang','','','','','','banner-trang-dat-hang.html','','','','',''),(11,11,'vn','Banner trang giá»›i thiá»‡u','Banner trang gioi thieu','','','','','','banner-trang-gioi-thieu.html','','','','',''),(12,12,'vn','Banner trang LiÃªn há»‡','Banner trang Lien he','','','','','','banner-trang-lien-he.html','','','','',''),(13,13,'vn','Banner trang cháº¿ Ä‘á»™ báº£o hÃ nh','Banner trang che do bao hanh','','','<p align=\"justify\">Lorem ipsum dolor sit amet, tempus dolor mattis turpis blandit turpis per, non tellus pellentesque vitae sed ut, amet quis facilisi consectetuer arcu in sed, lorem tempor praesent eget scelerisque vel rhoncus, wisi neque ultricies at quam. Posuere pulvinar wisi facilisis montes diam, orci diam quis in, risus sit lectus tellus aut, hac sodales eros suspendisse wisi id, placerat amet luctus nibh mus posuere. Mi dui id volutpat fermentum duis, nulla justo pellentesque ullamcorper lorem condimentum. Mollis pulvinar neque nec bibendum. Pretium etiam amet eu tristique sed, metus eligendi hac elementum non pede scelerisque, auctor posuere sem non non vel nullam, malesuada proin risus quam hymenaeos orci. Est malesuada ligula congue curabitur vestibulum diam, aliquam erat sed, euismod nunc elementum. Sit sed erat felis, vitae pellentesque id orci.</p>\r\n\r\n<p align=\"justify\">Lacus sem vehicula, lobortis commodo, quam quis, dui dui sed metus sit, in venenatis semper. Dictum neque elit fusce, gravida aliquam, aliquam nisl imperdiet augue nec. Parturient interdum amet amet felis wisi quis, velit ligula pellentesque pretium in ac, eu eleifend lacus hac, mattis cursus. Sed torquent lacus, tellus suspendisse libero suspendisse diam nullam. Ac congue, urna nullam ligula proin metus sodales, cum in mauris suspendisse fermentum porta, sit in pede et gravida eu, et venenatis etiam sollicitudin.</p>\r\n\r\n<p align=\"justify\">Lorem feugiat nullam dictumst diam mus. A a ac, ante arcu ad, eleifend sed sodales fusce ridiculus habitant fermentum, per incidunt malesuada montes vehicula risus, mauris elementum suspendisse. Sem pulvinar et placerat non, elit sit pede elit, in gravida ante molestie augue aliquam vehicula, magnis eget sapien laoreet. Mauris turpis vehicula, molestie tellus, vel libero diam vestibulum risus ultrices eget, euismod adipiscing cursus, eu sociosqu nunc pellentesque donec volutpat nullam. Vitae sed wisi, et elit ipsum nibh elit quam, vestibulum praesent molestiae odio dictum lobortis, suscipit porttitor lacus curabitur donec eget. Nibh eu, at lacinia eleifend, fringilla vestibulum, feugiat ut quis ligula, integer suscipit pellentesque dignissim arcu.</p>\r\n','<p align=\"justify\">Lorem ipsum dolor sit amet, tempus dolor mattis turpis blandit turpis per, non tellus pellentesque vitae sed ut, amet quis facilisi consectetuer arcu in sed, lorem tempor praesent eget scelerisque vel rhoncus, wisi neque ultricies at quam. Posuere pulvinar wisi facilisis montes diam, orci diam quis in, risus sit lectus tellus aut, hac sodales eros suspendisse wisi id, placerat amet luctus nibh mus posuere. Mi dui id volutpat fermentum duis, nulla justo pellentesque ullamcorper lorem condimentum. Mollis pulvinar neque nec bibendum. Pretium etiam amet eu tristique sed, metus eligendi hac elementum non pede scelerisque, auctor posuere sem non non vel nullam, malesuada proin risus quam hymenaeos orci. Est malesuada ligula congue curabitur vestibulum diam, aliquam erat sed, euismod nunc elementum. Sit sed erat felis, vitae pellentesque id orci.</p>\r\n\r\n<p align=\"justify\">Lacus sem vehicula, lobortis commodo, quam quis, dui dui sed metus sit, in venenatis semper. Dictum neque elit fusce, gravida aliquam, aliquam nisl imperdiet augue nec. Parturient interdum amet amet felis wisi quis, velit ligula pellentesque pretium in ac, eu eleifend lacus hac, mattis cursus. Sed torquent lacus, tellus suspendisse libero suspendisse diam nullam. Ac congue, urna nullam ligula proin metus sodales, cum in mauris suspendisse fermentum porta, sit in pede et gravida eu, et venenatis etiam sollicitudin.</p>\r\n\r\n<p align=\"justify\">Lorem feugiat nullam dictumst diam mus. A a ac, ante arcu ad, eleifend sed sodales fusce ridiculus habitant fermentum, per incidunt malesuada montes vehicula risus, mauris elementum suspendisse. Sem pulvinar et placerat non, elit sit pede elit, in gravida ante molestie augue aliquam vehicula, magnis eget sapien laoreet. Mauris turpis vehicula, molestie tellus, vel libero diam vestibulum risus ultrices eget, euismod adipiscing cursus, eu sociosqu nunc pellentesque donec volutpat nullam. Vitae sed wisi, et elit ipsum nibh elit quam, vestibulum praesent molestiae odio dictum lobortis, suscipit porttitor lacus curabitur donec eget. Nibh eu, at lacinia eleifend, fringilla vestibulum, feugiat ut quis ligula, integer suscipit pellentesque dignissim arcu.</p>\r\n','','banner-trang-che-do-bao-hanh.html','','','','',''),(14,14,'vn','Banner trang thanh toÃ¡n trá»±c tuyáº¿n','Banner trang thanh toan truc tuyen','','','','','','banner-trang-thanh-toan-truc-tuyen.html','','','','',''),(15,15,'vn','Äáº¡i lÃ½ #1','Dai ly #1','','','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 09090909090</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 53 Nguyá»…n VÄƒn Linh, Háº£i Ch&acirc;u, Ä&agrave; Náºµng</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: abc@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: abc.com.vn</p>\r\n','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 09090909090</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 53 Nguyen Van Linh, Hai Ch&acirc;u, D&agrave; Nang</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: abc@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: abc.com.vn</p>\r\n','','dai-ly-1.html','','','','',''),(16,16,'vn','sá»± kiá»‡n khai trÆ°Æ¡ng cá»­a hÃ ng','su kien khai truong cua hang','','','<p>TÆ°ng bá»«ng khuyáº¿n m&atilde;i</p>\r\n','<p>Tung bung khuyen m&atilde;i</p>\r\n','','dai-ly-2.html','','','','',''),(17,17,'vn','Sá»± kiá»‡n khuyáº¿n mÃ£i','Su kien khuyen mai','','','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cáº©m Lá»‡, Ä&agrave; Náºµng</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cam Le, D&agrave; Nang</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','','dai-ly-3.html','','','','',''),(18,18,'vn','Äáº¡i lÃ½ ','Dai ly ','','','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cáº©m Lá»‡, Ä&agrave; Náºµng</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cam Le, D&agrave; Nang</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','','dai-ly-4.html','','','','',''),(19,19,'vn','Banner trang danh sÃ¡ch Ä‘áº¡i lÃ½','Banner trang danh sach dai ly','','','','','','banner-trang-danh-sach-dai-ly.html','','','','',''),(78,61,'vn','DAO SPA MAMA - XÃ”NG Táº®M CHO PHá»¤ Ná»® SAU SINH','DAO SPA MAMA - XONG TAM CHO PHU NU SAU SINH','Sá»­ dá»¥ng cho sáº£n phá»¥ Ä‘á»ƒ xÃ´ng táº¯m chá»‘ng cáº£m vÃ  cÃ¡c chá»©ng háº­u sáº£n thÆ°á»ng gáº·p trong giai Ä‘oáº¡n kiÃªng cá»¯ thÃ¡ng Ä‘áº§u sau khi sinh.','Su dung cho san phu de xong tam chong cam va cac chung hau san thuong gap trong giai doan kieng cu thang dau sau khi sinh.','<p><strong>Th&agrave;nh pháº§n:&nbsp;</strong><br />\r\nDá»‹ch chiáº¿t CÆ¡m ch&aacute;y (Sambucus javanica extract), dá»‹ch chiáº¿t Hoa &ocirc;ng l&atilde;o (Clematis uncinata extract), dá»‹ch chiáº¿t Li&ecirc;n Ä‘áº±ng hoa nhá» (Illigera parviflora extract), dá»‹ch chiáº¿t Ch&ugrave;a d&ugrave; (Elsholtzia penduliflora extract), dá»‹ch chiáº¿t m&agrave;ng tang (Litsea cubeba extract), nÆ°á»›c tinh khiáº¿t, nipagin, nipasol.</p>\r\n\r\n<p><strong>C&aacute;ch sá»­ dá»¥ng:</strong> X&ocirc;ng hÆ¡i, táº¯m dá»™i:<br />\r\n- Chuáº©n bá»‹ cháº­u nhá» nÆ°á»›c s&ocirc;i (5-10 L&iacute;t); láº¯c Ä‘á»u, pha 1 lá» nÆ°á»›c táº¯m Dao&rsquo;spa v&agrave;o cháº­u, khuáº¥y Ä‘á»u; x&ocirc;ng hÆ¡i trong 5-10 ph&uacute;t cho ra má»“ h&ocirc;i to&agrave;n cÆ¡ thá»ƒ.<br />\r\n- Pha lo&atilde;ng nÆ°á»›c x&ocirc;ng ra cháº­u lá»›n Ä‘á»ƒ Ä‘Æ°á»£c nhiá»‡t Ä‘á»™ vá»«a pháº£i; cho&agrave;ng khÄƒn táº¯m quanh ngÆ°á»i, dá»™i nÆ°á»›c táº¯m vá»«a pha tá»« tá»« Ä‘á»ƒ tháº¥m Ä‘á»u v&agrave;o khÄƒn, táº¯m trong 5-10 ph&uacute;t. Táº¯m xong lau kh&ocirc; ngÆ°á»i, kh&ocirc;ng tr&aacute;ng láº¡i báº±ng nÆ°á»›c th&ocirc;ng thÆ°á»ng. Trong l&uacute;c táº¯m c&oacute; thá»ƒ gá»™i Ä‘áº§u b&igrave;nh thÆ°á»ng.</p>\r\n\r\n<p><strong>Liá»‡u tr&igrave;nh táº¯m:&nbsp;</strong><br />\r\nBáº¡n n&ecirc;n táº¯m sau khi sinh 3 ng&agrave;y náº¿u sinh thÆ°á»ng, 7 ng&agrave;y náº¿u sinh má»• (Sau khi váº¿t má»• Ä‘&atilde; kh&ocirc;); sá»­ dá»¥ng 6 ng&agrave;y li&ecirc;n tá»¥c hoáº·c c&aacute;ch ng&agrave;y.</p>\r\n\r\n<p><strong>Ch&uacute; &yacute;:&nbsp;</strong><br />\r\nKh&ocirc;ng sá»­ dá»¥ng cho ngÆ°á»i c&oacute; tiá»n sá»­ máº«n cáº£m vá»›i báº¥t cá»© th&agrave;nh pháº§n cá»§a sáº£n pháº©m.<br />\r\nKh&ocirc;ng sá»­ dá»¥ng khi say rÆ°á»£u bia hoáº·c Ä‘ang trong ká»³ kinh nguyá»‡t.&nbsp;<br />\r\nTháº­n trá»ng vá»›i ngÆ°á»i c&oacute; tiá»n sá»­ tim máº¡ch hoáº·c huyáº¿t &aacute;p.&nbsp;<br />\r\nÄá»ƒ xa táº§m tay tráº» em, Ä‘á»c ká»¹ hÆ°á»›ng dáº«n sá»­ dá»¥ng trÆ°á»›c khi d&ugrave;ng.</p>\r\n\r\n<p><strong>Báº£o quáº£n:</strong> Äá»ƒ nÆ¡i kh&ocirc; m&aacute;t, tr&aacute;nh &aacute;nh s&aacute;ng.</p>\r\n\r\n<p><strong>Quy c&aacute;ch Ä‘&oacute;ng g&oacute;i:</strong> Há»™p 3 lá» x 250ml, má»—i lá» d&ugrave;ng 1 láº§n.</p>\r\n\r\n<p><strong>Ti&ecirc;u chuáº©n: </strong>TCCS.</p>\r\n\r\n<p><strong>Sá»‘ Ä‘Äƒng k&yacute;:</strong> 515/13/CBMP-HN.</p>\r\n\r\n<p><strong>Háº¡n sá»­ dá»¥ng:</strong> 24 th&aacute;ng ká»ƒ tá»« ng&agrave;y sáº£n xuáº¥t.&nbsp;</p>\r\n\r\n<div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"360\" src=\"https://www.youtube.com/embed/iwTNMJTmChw\" style=\"position:absolute;top:0;left:0;width:100%;height:100%\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n','<p><strong>Th&agrave;nh phan:&nbsp;</strong><br />\r\nDich chiet Com ch&aacute;y (Sambucus javanica extract), dich chiet Hoa &ocirc;ng l&atilde;o (Clematis uncinata extract), dich chiet Li&ecirc;n dang hoa nho (Illigera parviflora extract), dich chiet Ch&ugrave;a d&ugrave; (Elsholtzia penduliflora extract), dich chiet m&agrave;ng tang (Litsea cubeba extract), nuoc tinh khiet, nipagin, nipasol.</p>\r\n\r\n<p><strong>C&aacute;ch su dung:</strong> X&ocirc;ng hoi, tam doi:<br />\r\n- Chuan bi chau nho nuoc s&ocirc;i (5-10 L&iacute;t); lac deu, pha 1 lo nuoc tam Dao&rsquo;spa v&agrave;o chau, khuay deu; x&ocirc;ng hoi trong 5-10 ph&uacute;t cho ra mo h&ocirc;i to&agrave;n co the.<br />\r\n- Pha lo&atilde;ng nuoc x&ocirc;ng ra chau lon de duoc nhiet do vua phai; cho&agrave;ng khan tam quanh nguoi, doi nuoc tam vua pha tu tu de tham deu v&agrave;o khan, tam trong 5-10 ph&uacute;t. Tam xong lau kh&ocirc; nguoi, kh&ocirc;ng tr&aacute;ng lai bang nuoc th&ocirc;ng thuong. Trong l&uacute;c tam c&oacute; the goi dau b&igrave;nh thuong.</p>\r\n\r\n<p><strong>Lieu tr&igrave;nh tam:&nbsp;</strong><br />\r\nBan n&ecirc;n tam sau khi sinh 3 ng&agrave;y neu sinh thuong, 7 ng&agrave;y neu sinh mo (Sau khi vet mo d&atilde; kh&ocirc;); su dung 6 ng&agrave;y li&ecirc;n tuc hoac c&aacute;ch ng&agrave;y.</p>\r\n\r\n<p><strong>Ch&uacute; &yacute;:&nbsp;</strong><br />\r\nKh&ocirc;ng su dung cho nguoi c&oacute; tien su man cam voi bat cu th&agrave;nh phan cua san pham.<br />\r\nKh&ocirc;ng su dung khi say ruou bia hoac dang trong ky kinh nguyet.&nbsp;<br />\r\nThan trong voi nguoi c&oacute; tien su tim mach hoac huyet &aacute;p.&nbsp;<br />\r\nDe xa tam tay tre em, doc ky huong dan su dung truoc khi d&ugrave;ng.</p>\r\n\r\n<p><strong>Bao quan:</strong> De noi kh&ocirc; m&aacute;t, tr&aacute;nh &aacute;nh s&aacute;ng.</p>\r\n\r\n<p><strong>Quy c&aacute;ch d&oacute;ng g&oacute;i:</strong> Hop 3 lo x 250ml, moi lo d&ugrave;ng 1 lan.</p>\r\n\r\n<p><strong>Ti&ecirc;u chuan: </strong>TCCS.</p>\r\n\r\n<p><strong>So dang k&yacute;:</strong> 515/13/CBMP-HN.</p>\r\n\r\n<p><strong>Han su dung:</strong> 24 th&aacute;ng ke tu ng&agrave;y san xuat.&nbsp;</p>\r\n\r\n<div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden\"><iframe allowfullscreen=\"\" frameborder=\"0\" height=\"360\" src=\"https://www.youtube.com/embed/iwTNMJTmChw\" style=\"position:absolute;top:0;left:0;width:100%;height:100%\" width=\"640\"></iframe></div>\r\n\r\n<p>&nbsp;</p>\r\n','','dao-spa-mama-xong-tam-cho-phu-nu-sau-sinh.html','','','320000','',''),(79,62,'vn','Lá»u xÃ´ng hÆ¡i','Leu xong hoi','Lá»u xÃ´ng hÆ¡i sau sinh káº¿t há»£p vá»›i nÆ°á»›c táº¯m Daospa Mama sáº½ giÃºp cÃ¡c máº¹ xÃ´ng táº¯m sau sinh dá»… dÃ ng, nhanh chÃ³ng, giÃºp há»“i phá»¥c sá»©c khá»e, giáº£m cÃ¢n an toÃ n','Leu xong hoi sau sinh ket hop voi nuoc tam Daospa Mama se giup cac me xong tam sau sinh de dang, nhanh chong, giup hoi phuc suc khoe, giam can an toan','<p><span style=\"color: rgb(0, 128, 0);\"><span style=\"font-size: 16px;\"><strong>Lá»u x&ocirc;ng hÆ¡i sau sinh</strong></span></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">X&ocirc;ng hÆ¡ sau sinh l&agrave; viá»‡c cáº§n thiáº¿t vá»›i táº¥t cáº£ c&aacute;c b&agrave; máº¹ tráº» sau sinh Ä‘á»ƒ phá»¥c há»“i sá»©c khá»e, chá»‘ng c&aacute;c bá»‡nh háº­u sáº£n. Tuy nhi&ecirc;n, náº¿u viá»‡c x&ocirc;ng hÆ¡ sau sinh quan trá»ng nhÆ° tháº¿ th&igrave; qu&aacute; tr&igrave;nh tiáº¿n h&agrave;nh láº¡i ráº¥t kh&oacute; khÄƒn, váº¥t váº£:</span></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/images/leu-xong-hoi-lxh01x-2-700x700.jpg\" /></p>\r\n\r\n<p style=\"text-align: center;\"><em><span style=\"font-size: 14px;\">Lá»u x&ocirc;ng hÆ¡i sau sinh tá»± Ä‘á»™ng - kh&ocirc;ng cáº§n láº¯p r&aacute;p</span></em></p>\r\n\r\n<p><span style=\"color: rgb(0, 128, 0);\"><span style=\"font-size: 16px;\"><strong><u>Cá»¥ thá»ƒ báº¡n pháº£i chuáº©n bá»‹:</u></strong></span></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">1./ Pháº£i c&oacute; &iacute;t nháº¥t má»™t ngÆ°á»i lá»›n há»— trá»£ nhÆ° bÆ°ng ná»“i nÆ°á»›c n&oacute;ng, ch&ugrave;m chÄƒm qua Ä‘áº§u khi báº¡n ngá»“i xuá»‘ng.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">2./ Pháº£i sá»­ dá»¥ng &iacute;t nháº¥t 2 c&aacute;i chÄƒn má»›i phá»§ k&iacute;n Ä‘Æ°á»£c, tuy nhi&ecirc;n cháº¥t liá»‡u chÄƒn tho&aacute;ng m&aacute;t n&ecirc;n kh&ocirc;ng giá»¯ Ä‘Æ°á»£c hÆ¡i n&oacute;ng l&acirc;u.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">3./ Pháº£i giáº·t láº¡i 2 c&aacute;i chÄƒn sau khi sá»­ dá»¥ng &ndash; Ä‘á»‘i vá»›i ngÆ°á»i phá»¥ ná»¯ má»›i sinh xong th&igrave; Ä‘&oacute; l&agrave; má»™t &aacute;c má»™ng thá»±c sá»±.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">4./ Bá»‹ 2 c&aacute;i chÄƒn Ä‘&egrave; náº·ng l&ecirc;n ngÆ°á»i n&ecirc;n kh&ocirc;ng tháº¥y thoáº£i m&aacute;i g&igrave; m&agrave; ngÆ°á»£c láº¡i ráº¥t ngá»™t ngáº¡t, x&ocirc;ng xong báº¡n sáº½ bá»‹ má»i cá»•, má»i vai.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">5./ Äáº·c biá»‡t náº¿u sÆ¡ &yacute; sáº½ pháº£i g&aacute;nh chá»‹u háº­u quáº£ kh&ocirc;n lÆ°á»ng l&agrave; bá»‹ bá»ng.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">6./ Sau khi x&ocirc;ng xong, báº¡n nhá»› l&agrave; pháº£i lau nh&agrave; v&igrave; nÆ°á»›c tháº¥m háº¿t ra nh&agrave;.</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size:14px;\"><em>NÆ°á»›c táº¯m Daospa Mama v&agrave; lá»u x&ocirc;ng hÆ¡i sau sinh tá»± Ä‘á»™ng cho máº¹ sau sinh</em></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">=&gt;&nbsp;<em>N&oacute;i chung l&agrave; ráº¥t ráº¥t báº¥t tiá»‡n v&agrave; má»‡t má»i</em>. Ä&acirc;y cÅ©ng ch&iacute;nh l&agrave; nguy&ecirc;n nh&acirc;n ch&iacute;nh khiáº¿n c&aacute;c máº¹ cháº³ng há»©ng th&uacute; hoáº·c kh&ocirc;ng ki&ecirc;n tr&igrave; viá»‡c x&ocirc;ng hÆ¡i cáº£ th&aacute;ng á»Ÿ cá»¯ sau khi sinh Ä‘Æ°á»£c.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">Váº­y<strong>&nbsp;lá»u x&ocirc;ng hÆ¡i sau sinh</strong>&nbsp;tá»± Ä‘á»™ng - kh&ocirc;ng cáº§n láº¯p r&aacute;p sáº½ gi&uacute;p ngÆ°á»i phá»¥ ná»¯ sau sinh giáº£i quyáº¿t háº¿t táº¥t cáº£ má»™t Ä‘á»‘ng kh&oacute; khÄƒn tr&ecirc;n.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">V&agrave; ngo&agrave;i ra, nhá»¯ng th&agrave;nh vi&ecirc;n trong gia Ä‘&igrave;nh Ä‘á»u c&oacute; thá»ƒ sá»­ dá»¥ng Ä‘Æ°á»£c, nháº¥t l&agrave; c&aacute;c b&eacute; nhá» sau n&agrave;y c&oacute; thá»ƒ l&agrave;m má»™t khu vui chÆ¡i ri&ecirc;ng cho m&igrave;nh, tá»± do s&aacute;ng táº¡o.</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14px;\"><em>Lá»u x&ocirc;ng hÆ¡i tá»± Ä‘á»™ng - tháº­t sá»± thoáº£i m&aacute;i</em></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">Sáº£n pháº©m&nbsp;<strong>lá»u x&ocirc;ng hÆ¡i sau sinh</strong>&nbsp;tá»± Ä‘á»™ng c&oacute; t&aacute;c dá»¥ng:</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>1./&nbsp;<u>Kh&ocirc;ng bá»‹ Ä‘au váº¿t sanh</u>:</strong>&nbsp;Báº£n th&acirc;n phá»¥ ná»¯ sau sinh th&igrave; váº¿t má»• (ráº¡ch táº§ng sinh m&ocirc;n) chÆ°a há»“i phá»¥c, n&ecirc;n pháº£i ngá»“i l&ecirc;n 1 gháº¿ (cao tá»« 30 &ndash; 40 cm) Ä‘á»ƒ tr&aacute;nh g&ograve; v&agrave;o váº¿t thÆ°Æ¡ng, kh&ocirc;ng thá»ƒ ngá»“i xuá»‘ng Ä‘áº¥t Ä‘Æ°á»£c.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>2./&nbsp;<u>X&ocirc;ng Ä‘Æ°á»£c cá»­a m&igrave;nh</u>:</strong>&nbsp;Äá»“ng thá»i cáº§n pháº£i ngá»“i l&ecirc;n gháº¿ nhÆ° tháº¿ Ä‘á»ƒ x&ocirc;ng cá»­a m&igrave;nh, nháº±m Ä‘áº§y nhá»¯ng cháº¥t dÆ¡ c&ograve;n s&oacute;t láº¡i ra ngo&agrave;i, gi&uacute;p tá»­ cung nhanh ch&oacute;ng trá»Ÿ vá» tráº¡ng th&aacute;i ban Ä‘áº§u, gi&uacute;p ph&ograve;ng chá»‘ng viá»‡c sa tá»­ cung</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>3./&nbsp;<u>Tháº­t sá»± thoáº£i m&aacute;i:</u></strong>&nbsp;lá»u x&ocirc;ng hÆ¡i sau sinh tá»± Ä‘á»™ng, chá»‰ cáº§n má»Ÿ ra v&agrave; ngá»“i v&agrave;o l&agrave; c&oacute; thá»ƒ thoáº£i m&aacute;i cáº£m nháº­n Ä‘Æ°á»£c hÆ°Æ¡ng thÆ¡m cá»§a ná»“i nÆ°á»›c x&ocirc;ng, kh&ocirc;ng cáº§n láº¯p r&aacute;p, tiá»‡n lá»£i vá»›i báº¥t ká»³ má»i ngÆ°á»i.</span></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/images/leuxong(1).jpg\" /></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14px;\"><em>Láº¯p r&aacute;p nhanh ch&oacute;ng dá»… d&agrave;ng</em></span></p>\r\n','<p><span style=\"color: rgb(0, 128, 0);\"><span style=\"font-size: 16px;\"><strong>Leu x&ocirc;ng hoi sau sinh</strong></span></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">X&ocirc;ng ho sau sinh l&agrave; viec can thiet voi tat ca c&aacute;c b&agrave; me tre sau sinh de phuc hoi suc khoe, chong c&aacute;c benh hau san. Tuy nhi&ecirc;n, neu viec x&ocirc;ng ho sau sinh quan trong nhu the th&igrave; qu&aacute; tr&igrave;nh tien h&agrave;nh lai rat kh&oacute; khan, vat va:</span></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/images/leu-xong-hoi-lxh01x-2-700x700.jpg\" /></p>\r\n\r\n<p style=\"text-align: center;\"><em><span style=\"font-size: 14px;\">Leu x&ocirc;ng hoi sau sinh tu dong - kh&ocirc;ng can lap r&aacute;p</span></em></p>\r\n\r\n<p><span style=\"color: rgb(0, 128, 0);\"><span style=\"font-size: 16px;\"><strong><u>Cu the ban phai chuan bi:</u></strong></span></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">1./ Phai c&oacute; &iacute;t nhat mot nguoi lon ho tro nhu bung noi nuoc n&oacute;ng, ch&ugrave;m cham qua dau khi ban ngoi xuong.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">2./ Phai su dung &iacute;t nhat 2 c&aacute;i chan moi phu k&iacute;n duoc, tuy nhi&ecirc;n chat lieu chan tho&aacute;ng m&aacute;t n&ecirc;n kh&ocirc;ng giu duoc hoi n&oacute;ng l&acirc;u.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">3./ Phai giat lai 2 c&aacute;i chan sau khi su dung &ndash; doi voi nguoi phu nu moi sinh xong th&igrave; d&oacute; l&agrave; mot &aacute;c mong thuc su.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">4./ Bi 2 c&aacute;i chan d&egrave; nang l&ecirc;n nguoi n&ecirc;n kh&ocirc;ng thay thoai m&aacute;i g&igrave; m&agrave; nguoc lai rat ngot ngat, x&ocirc;ng xong ban se bi moi co, moi vai.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">5./ Dac biet neu so &yacute; se phai g&aacute;nh chiu hau qua kh&ocirc;n luong l&agrave; bi bong.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">6./ Sau khi x&ocirc;ng xong, ban nho l&agrave; phai lau nh&agrave; v&igrave; nuoc tham het ra nh&agrave;.</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size:14px;\"><em>Nuoc tam Daospa Mama v&agrave; leu x&ocirc;ng hoi sau sinh tu dong cho me sau sinh</em></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">=&gt;&nbsp;<em>N&oacute;i chung l&agrave; rat rat bat tien v&agrave; met moi</em>. D&acirc;y cung ch&iacute;nh l&agrave; nguy&ecirc;n nh&acirc;n ch&iacute;nh khien c&aacute;c me chang hung th&uacute; hoac kh&ocirc;ng ki&ecirc;n tr&igrave; viec x&ocirc;ng hoi ca th&aacute;ng o cu sau khi sinh duoc.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">Vay<strong>&nbsp;leu x&ocirc;ng hoi sau sinh</strong>&nbsp;tu dong - kh&ocirc;ng can lap r&aacute;p se gi&uacute;p nguoi phu nu sau sinh giai quyet het tat ca mot dong kh&oacute; khan tr&ecirc;n.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">V&agrave; ngo&agrave;i ra, nhung th&agrave;nh vi&ecirc;n trong gia d&igrave;nh deu c&oacute; the su dung duoc, nhat l&agrave; c&aacute;c b&eacute; nho sau n&agrave;y c&oacute; the l&agrave;m mot khu vui choi ri&ecirc;ng cho m&igrave;nh, tu do s&aacute;ng tao.</span></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14px;\"><em>Leu x&ocirc;ng hoi tu dong - that su thoai m&aacute;i</em></span></p>\r\n\r\n<p><span style=\"font-size: 16px;\">San pham&nbsp;<strong>leu x&ocirc;ng hoi sau sinh</strong>&nbsp;tu dong c&oacute; t&aacute;c dung:</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>1./&nbsp;<u>Kh&ocirc;ng bi dau vet sanh</u>:</strong>&nbsp;Ban th&acirc;n phu nu sau sinh th&igrave; vet mo (rach tang sinh m&ocirc;n) chua hoi phuc, n&ecirc;n phai ngoi l&ecirc;n 1 ghe (cao tu 30 &ndash; 40 cm) de tr&aacute;nh g&ograve; v&agrave;o vet thuong, kh&ocirc;ng the ngoi xuong dat duoc.</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>2./&nbsp;<u>X&ocirc;ng duoc cua m&igrave;nh</u>:</strong>&nbsp;Dong thoi can phai ngoi l&ecirc;n ghe nhu the de x&ocirc;ng cua m&igrave;nh, nham day nhung chat do c&ograve;n s&oacute;t lai ra ngo&agrave;i, gi&uacute;p tu cung nhanh ch&oacute;ng tro ve trang th&aacute;i ban dau, gi&uacute;p ph&ograve;ng chong viec sa tu cung</span></p>\r\n\r\n<p><span style=\"font-size: 16px;\"><strong>3./&nbsp;<u>That su thoai m&aacute;i:</u></strong>&nbsp;leu x&ocirc;ng hoi sau sinh tu dong, chi can mo ra v&agrave; ngoi v&agrave;o l&agrave; c&oacute; the thoai m&aacute;i cam nhan duoc huong thom cua noi nuoc x&ocirc;ng, kh&ocirc;ng can lap r&aacute;p, tien loi voi bat ky moi nguoi.</span></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" src=\"/uploads/images/images/leuxong(1).jpg\" /></p>\r\n\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14px;\"><em>Lap r&aacute;p nhanh ch&oacute;ng de d&agrave;ng</em></span></p>\r\n','','leu-xong-hoi.html','','','','',''),(77,60,'vn','Táº¯m bÃ© tháº£o dÆ°á»£c ELEMIS','Tam be thao duoc ELEMIS','Táº¯m bÃ© tháº£o dÆ°á»£c ELEMIS cÃ³ thÃ nh pháº§n hoÃ n toÃ n tá»« 100% tháº£o dÆ°á»£c, sá»­ dá»¥ng cho tráº» sÆ¡ sinh, tráº» bá»‹ rÃ´m sáº©y, má»¥n nhá»t','Tam be thao duoc ELEMIS co thanh phan hoan toan tu 100% thao duoc, su dung cho tre so sinh, tre bi rom say, mun nhot','<p><strong>TH&Agrave;NH PHáº¦N:</strong><br />\r\nDiá»‡p lá»¥c tá»‘(Chlorophyl: chiáº¿t xuáº¥t tá»« l&aacute; tÆ°Æ¡i).<br />\r\nPapain (Chiáº¿t xuáº¥t tá»« c&acirc;y Ä‘u Ä‘á»§).<br />\r\nDá»‹ch chiáº¿t ch&egrave; xanh.<br />\r\nDá»‹ch chiáº¿t kinh giá»›i.<br />\r\nDá»‹ch chiáº¿t khá»• qua.<br />\r\nTinh dáº§u Chanh.<br />\r\nNÆ°á»›c tinh khiáº¿t.<br />\r\n<strong>Lá»¢I &Iacute;CH KHI Sá»¬ Dá»¤NG:</strong><br />\r\n- Diá»‡t khuáº©n, l&agrave;m sáº¡ch v&agrave; báº£o vá»‡ da, gi&uacute;p ngÄƒn ngá»«a v&agrave; giáº£m r&ocirc;m sáº£y, má»¥n nhá»t.<br />\r\n- L&agrave;m m&aacute;t da, giá»¯ da lu&ocirc;n má»m máº¡i, thÆ¡m m&aacute;t v&agrave; khá»e máº¡nh.<br />\r\n- L&agrave;m sáº¡ch an to&agrave;n c&aacute;c váº£y da Ä‘áº§u( cá»©t tr&acirc;u), l&ocirc;ng mÄƒng á»Ÿ tráº» sÆ¡ sinh v&agrave; tráº» nhá».<br />\r\n- Há»— trá»£ ph&ograve;ng, chá»“ng muá»—i.<br />\r\n<strong>HÆ¯á»šNG DáºªN Sá»¬ Dá»¤NG:</strong><br />\r\nCHUáº¨N Bá»Š NÆ¯á»šC Táº®M:</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/images/Pha-nuoc-tam-Elemis.jpg\" /></p>\r\n\r\n<p><em>LÆ°á»£ng nÆ°á»›c táº¯m sá»­ dá»¥ng phá»¥ thuá»™c v&agrave;o má»—i tráº». Pha dung dá»‹ch ELEMIS &nbsp;v&agrave;o nÆ°á»›c áº¥m theo tá»· lá»‡: 5ml ELEMIS h&ograve;a trong 5L nÆ°á»›c áº¥m.</em><br />\r\nC&Aacute;CH Táº®M:</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Cach-tam-Elemis.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Dung dá»‹ch d&ugrave;ng táº¯m gá»™i to&agrave;n th&acirc;n. Rá»­a máº·t, gá»™i Ä‘áº§u, ng&acirc;m ngÆ°á»i b&eacute; trong nÆ°á»›c táº¯m.</em></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Tri-mun-nhot.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Trong trÆ°á»ng há»£p r&ocirc;m sáº£y, má»¥n nhá»t: xoa trá»±c tiáº¿p ELEMIS l&ecirc;n v&ugrave;ng da bá»‹ r&ocirc;m sáº£y, má»¥n nhá»t khoáº£ng 1 &ndash; 2 ph&uacute;t, sau Ä‘&oacute; táº¯m b&eacute; trong nÆ°á»›c táº¯m Ä‘&atilde; pha.</em></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Lau-kho.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Táº¯m, gá»™i xong lau kh&ocirc; ngÆ°á»i kh&ocirc;ng tr&aacute;ng láº¡i báº±ng nÆ°á»›c th&ocirc;ng thÆ°á»ng.</em></p>\r\n\r\n<p><br />\r\n<strong>Li&ecirc;n há»‡:</strong></p>\r\n\r\n<p>Äá»‹a chá»‰: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cáº©m Lá»‡, Ä&agrave; Náºµng<br />\r\nÄiá»‡n thoáº¡i: <span style=\"color:#ff0000;\"><strong>0979041002</strong></span><br />\r\nEmail: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Elemis-400X400.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:12px\"><em><span style=\"color:rgb(0, 0, 0)\">Táº¯m b&eacute; tháº£o dÆ°á»£c ELEMIS c&oacute; th&agrave;nh pháº§n ho&agrave;n to&agrave;n tá»« 100% tháº£o dÆ°á»£c, sá»­ dá»¥ng cho tráº» sÆ¡ sinh, tráº» bá»‹ r&ocirc;m sáº©y, má»¥n nhá»t.</span></em></span></p>\r\n','<p><strong>TH&Agrave;NH PHAN:</strong><br />\r\nDiep luc to(Chlorophyl: chiet xuat tu l&aacute; tuoi).<br />\r\nPapain (Chiet xuat tu c&acirc;y du du).<br />\r\nDich chiet ch&egrave; xanh.<br />\r\nDich chiet kinh gioi.<br />\r\nDich chiet kho qua.<br />\r\nTinh dau Chanh.<br />\r\nNuoc tinh khiet.<br />\r\n<strong>LOI &Iacute;CH KHI SU DUNG:</strong><br />\r\n- Diet khuan, l&agrave;m sach v&agrave; bao ve da, gi&uacute;p ngan ngua v&agrave; giam r&ocirc;m say, mun nhot.<br />\r\n- L&agrave;m m&aacute;t da, giu da lu&ocirc;n mem mai, thom m&aacute;t v&agrave; khoe manh.<br />\r\n- L&agrave;m sach an to&agrave;n c&aacute;c vay da dau( cut tr&acirc;u), l&ocirc;ng mang o tre so sinh v&agrave; tre nho.<br />\r\n- Ho tro ph&ograve;ng, chong muoi.<br />\r\n<strong>HUONG DAN SU DUNG:</strong><br />\r\nCHUAN BI NUOC TAM:</p>\r\n\r\n<p><img alt=\"\" src=\"/uploads/images/images/Pha-nuoc-tam-Elemis.jpg\" /></p>\r\n\r\n<p><em>Luong nuoc tam su dung phu thuoc v&agrave;o moi tre. Pha dung dich ELEMIS &nbsp;v&agrave;o nuoc am theo ty le: 5ml ELEMIS h&ograve;a trong 5L nuoc am.</em><br />\r\nC&Aacute;CH TAM:</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Cach-tam-Elemis.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Dung dich d&ugrave;ng tam goi to&agrave;n th&acirc;n. Rua mat, goi dau, ng&acirc;m nguoi b&eacute; trong nuoc tam.</em></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Tri-mun-nhot.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Trong truong hop r&ocirc;m say, mun nhot: xoa truc tiep ELEMIS l&ecirc;n v&ugrave;ng da bi r&ocirc;m say, mun nhot khoang 1 &ndash; 2 ph&uacute;t, sau d&oacute; tam b&eacute; trong nuoc tam d&atilde; pha.</em></p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Lau-kho.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><em>Tam, goi xong lau kh&ocirc; nguoi kh&ocirc;ng tr&aacute;ng lai bang nuoc th&ocirc;ng thuong.</em></p>\r\n\r\n<p><br />\r\n<strong>Li&ecirc;n he:</strong></p>\r\n\r\n<p>Dia chi: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cam Le, D&agrave; Nang<br />\r\nDien thoai: <span style=\"color:#ff0000;\"><strong>0979041002</strong></span><br />\r\nEmail: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p style=\"text-align:center\"><img alt=\"\" src=\"/uploads/images/images/Elemis-400X400.jpg\" /></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:12px\"><em><span style=\"color:rgb(0, 0, 0)\">Tam b&eacute; thao duoc ELEMIS c&oacute; th&agrave;nh phan ho&agrave;n to&agrave;n tu 100% thao duoc, su dung cho tre so sinh, tre bi r&ocirc;m say, mun nhot.</span></em></span></p>\r\n','','tam-be-thao-duoc-elemis.html','','','','',''),(75,58,'vn','sá»± kiá»‡n khai trÆ°Æ¡ng cá»­a hÃ ng','su kien khai truong cua hang','chu thÃ­ch','chu thich','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cáº©m Lá»‡, Ä&agrave; Náºµng</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Tel: 0915531379</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Address: 26 T&ugrave;ng L&acirc;m 4, P. H&ograve;a Xu&acirc;n, Q. Cam Le, D&agrave; Nang</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Email: nguyenbaonguyen.vn@gmail.com</p>\r\n\r\n<p><span class=\"fa fa-caret-right\" style=\"color:rgb(0, 0, 0);\"></span>&nbsp;Website: http://baonguyendanang.com</p>\r\n','','su-kien-abc.html','','','','',''),(80,63,'vn','NÆ°á»›c hoa mini trÃ¡i tÃ¡o','Nuoc hoa mini trai tao','','','','','','nuoc-hoa-mini-trai-tao.html','','','499000','',''),(81,64,'vn','NÆ°á»›c hoa mini','Nuoc hoa mini','','','','','','nuoc-hoa-mini.html','','','499000','',''),(82,65,'vn','NÆ°á»›c hoa mini','Nuoc hoa mini','','','','','','nuoc-hoa-mini-s65.html','','','499000','',''),(83,66,'vn','NÆ°á»›c hoa mini','Nuoc hoa mini','','','','','','nuoc-hoa-mini-s66.html','','','499000','',''),(84,67,'vn','nÆ°á»›c hoa cao cáº¥p','nuoc hoa cao cap','','','<p>li&ecirc;n há»‡</p>\r\n','<p>li&ecirc;n he</p>\r\n','','nuoc-hoa-cao-cap.html','','','','',''),(85,68,'vn','nÆ°á»›c hoa cao cáº¥p','nuoc hoa cao cap','','','<p>li&ecirc;n há»‡</p>\r\n','<p>li&ecirc;n he</p>\r\n','','nuoc-hoa-cao-cap-s68.html','','','','',''),(86,69,'vn','nÆ°á»›c hoa cao cáº¥p','nuoc hoa cao cap','','','<p>li&ecirc;n há»‡</p>\r\n','<p>li&ecirc;n he</p>\r\n','','nuoc-hoa-cao-cap-s69.html','','','','',''),(87,70,'vn','NÆ°á»›c hoa mini','Nuoc hoa mini','','','','','','nuoc-hoa-mini-s70.html','','','499000','',''),(88,71,'vn','nÆ°á»›c hoa cao cáº¥p','nuoc hoa cao cap','','','<p>li&ecirc;n há»‡</p>\r\n','<p>li&ecirc;n he</p>\r\n','','nuoc-hoa-cao-cap-s71.html','','','','',''),(89,72,'vn','NÆ°á»›c hoa mini','Nuoc hoa mini','','','','','','nuoc-hoa-mini-s72.html','','','499000','499000','');
/*!40000 ALTER TABLE `post_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_meta`
--

DROP TABLE IF EXISTS `post_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `lang_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `meta_value` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_meta`
--

LOCK TABLES `post_meta` WRITE;
/*!40000 ALTER TABLE `post_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_meta_key`
--

DROP TABLE IF EXISTS `post_meta_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_meta_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thu_tu` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rows` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  `post_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `width` int(11) NOT NULL,
  `chu_thich` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `idmenu` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_meta_key`
--

LOCK TABLES `post_meta_key` WRITE;
/*!40000 ALTER TABLE `post_meta_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_meta_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postcat`
--

DROP TABLE IF EXISTS `postcat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postcat` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cat` int(5) NOT NULL,
  `hien_thi` int(2) NOT NULL,
  `noi_bat` int(1) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `level` int(1) NOT NULL,
  `post_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postcat`
--

LOCK TABLES `postcat` WRITE;
/*!40000 ALTER TABLE `postcat` DISABLE KEYS */;
INSERT INTO `postcat` VALUES (9,0,1,0,0,1,'news'),(7,0,1,0,0,1,'other'),(8,0,1,0,1,1,'post'),(28,0,1,1,2,1,'catproduct'),(29,8,1,0,1,2,'post'),(30,8,1,0,2,2,'post'),(31,0,1,1,1,1,'catproduct'),(46,28,1,0,0,2,'catproduct'),(45,28,1,0,0,2,'catproduct'),(47,31,1,0,0,2,'catproduct'),(38,31,1,0,1,2,'catproduct'),(42,8,1,0,3,2,'post'),(48,0,1,0,0,1,'catproduct');
/*!40000 ALTER TABLE `postcat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postcat_lang`
--

DROP TABLE IF EXISTS `postcat_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postcat_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postcat_id` int(11) NOT NULL,
  `lang_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title_seo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postcat_lang`
--

LOCK TABLES `postcat_lang` WRITE;
/*!40000 ALTER TABLE `postcat_lang` DISABLE KEYS */;
INSERT INTO `postcat_lang` VALUES (10,9,'vn','Tuyá»ƒn dá»¥ng','tuyen-dung','','','',''),(7,7,'vn','Banner trang con','banner-trang-con','','','',''),(8,8,'vn','Danh sÃ¡ch cá»­a hÃ ng','danh-sach-cua-hang','','','',''),(9,8,'en','Store listing','store-listing','','','',''),(11,9,'en','Recruitment','recruitment','','','',''),(30,28,'vn','Sáº£n pháº©m dÃ nh cho bÃ©','san-pham-danh-cho-be','','','',''),(31,29,'vn','ÄÃ  Náºµng','da-nang','','','',''),(32,30,'vn','Huáº¿','hue','','','',''),(33,28,'en','Body care products','body-care-products','','','',''),(34,31,'vn','Sáº£n pháº©m dÃ nh cho máº¹','san-pham-danh-cho-me','','','',''),(35,31,'en','Skin care products','skin-care-products','','','',''),(60,46,'vn','Tinh Dáº§u TrÃ m','tinh-dau-tram','','','',''),(59,45,'vn','Táº¯m bÃ© tháº£o dÆ°á»£c ELEMIS','tam-be-thao-duoc-elemis','','','',''),(61,47,'vn','Lá»u XÃ´ng HÆ¡i','leu-xong-hoi','','','',''),(48,38,'vn','DAO SPA MAMA','dao-spa-mama','','','',''),(49,38,'en','Advance product','advance-product','','','',''),(56,42,'vn','QN','qn','','','',''),(62,48,'vn','Sáº£n pháº©m lÃ m Ä‘áº¹p','san_pham_lam_dep','','','','');
/*!40000 ALTER TABLE `postcat_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_bien`
--

DROP TABLE IF EXISTS `vn_bien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_bien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(50) NOT NULL,
  `gia_tri` text NOT NULL,
  `nhom` varchar(50) NOT NULL,
  `lang` varchar(5) NOT NULL DEFAULT 'none',
  `ten` varchar(50) NOT NULL,
  `sort` int(3) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_bien`
--

LOCK TABLES `vn_bien` WRITE;
/*!40000 ALTER TABLE `vn_bien` DISABLE KEYS */;
INSERT INTO `vn_bien` VALUES (1,'title','Sáº£n pháº©m chÄƒm sÃ³c sá»©c khá»e máº¹ vÃ  bÃ©','GENERAL','vn','TiÃªu Ä‘á»',0,1),(2,'address','26 TÃ¹ng LÃ¢m 4, P. HÃ²a XuÃ¢n, Q. Cáº©m Lá»‡,  ÄÃ  Náºµng','GENERAL','vn','Äá»‹a chá»‰',1,1),(3,'meta_author','VinaDesign','GENERAL','vn','Author',2,1),(4,'meta_description','Sáº£n pháº©m chÄƒm sÃ³c sá»©c khá»e máº¹ vÃ  bÃ©','GENERAL','vn','Decription',3,1),(5,'meta_keywords','Sáº£n pháº©m chÄƒm sÃ³c sá»©c khá»e máº¹ vÃ  bÃ©','GENERAL','vn','Keywords',4,1),(6,'meta_copyright','Copyrights Â© 2018 www.baonguyendanang','GENERAL','vn','Copyright',5,1),(7,'title','DAESA','GENERAL','en','Title',0,1),(13,'email','nguyenbaonguyen.vn@gmail.com','OTHER','none','Email',0,1),(8,'address','','GENERAL','en','Address',1,1),(9,'meta_author','','GENERAL','en','Author',2,1),(10,'meta_description','','GENERAL','en','Decription',3,1),(11,'meta_keywords','','GENERAL','en','Keywords',4,1),(12,'meta_copyright','COPYRIGHTS Â© 2017 ALL RIGHTS RESERVED','GENERAL','en','Copyright',5,1),(14,'email_transport','noreplay365@gmail.com','PHPMAILER','none','Email Transport',0,1),(15,'pass_transport','Vinadesign@365d235','PHPMAILER','none','Pass Transport',0,1),(16,'RESIZE1','370x411','RESIZE','none','Sáº£n pháº©m',0,1),(17,'facebook','https://www.facebook.com/M%E1%BB%B9-Ph%E1%BA%A9m-DAESA-334408123738178/','SOCIAL','none','Facebook',0,1),(18,'skype','longcaodn','SOCIAL','none','Skyper',0,1),(19,'google-plus','https://plus.google.com/ ','SOCIAL','none','Google',0,1),(20,'phone','','OTHER','none','Phone',1,1),(21,'hotline','0979041002-0915531379','OTHER','none','Hotline',2,1),(22,'maps','15.989302, 108.215282','OTHER','none','Maps',3,1);
/*!40000 ALTER TABLE `vn_bien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_cat`
--

DROP TABLE IF EXISTS `vn_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ten_en` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hien_thi` int(1) NOT NULL,
  `noi_bat` int(1) NOT NULL,
  `hinh` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `thu_tu` int(11) NOT NULL DEFAULT '1',
  `_product` int(1) DEFAULT '0',
  `_cms` int(1) NOT NULL DEFAULT '0',
  `_gallery` int(1) NOT NULL DEFAULT '0',
  `_file` int(1) NOT NULL DEFAULT '0',
  `_list` int(1) NOT NULL DEFAULT '0',
  `_project` int(1) NOT NULL DEFAULT '0',
  `_anhsp` int(1) NOT NULL DEFAULT '0',
  `_filesp` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_cat`
--

LOCK TABLES `vn_cat` WRITE;
/*!40000 ALTER TABLE `vn_cat` DISABLE KEYS */;
INSERT INTO `vn_cat` VALUES (1,'List','List',0,0,'',1,0,0,0,0,1,0,0,0),(2,'Gallery','Gallery',1,1,'',1,0,0,1,0,0,0,0,0),(3,'Album','Album',1,0,'',1,0,0,0,0,0,0,1,0),(5,'File Manager','',1,0,'',1,0,0,0,1,0,0,0,0),(7,'ThÆ° viá»‡n','',1,0,'',1,0,0,1,0,0,0,0,0),(9,'Video','video',0,0,'',1,0,0,0,0,0,0,0,1),(10,'File','',1,0,'',1,0,0,1,0,0,0,0,0);
/*!40000 ALTER TABLE `vn_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_danhgia`
--

DROP TABLE IF EXISTS `vn_danhgia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_danhgia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) NOT NULL,
  `hoten` varchar(255) NOT NULL,
  `danhgia` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `kiem_duyet` int(1) NOT NULL DEFAULT '0',
  `noi_dung` text NOT NULL,
  `traloi` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `cat` int(11) NOT NULL,
  `luot_xem` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_danhgia`
--

LOCK TABLES `vn_danhgia` WRITE;
/*!40000 ALTER TABLE `vn_danhgia` DISABLE KEYS */;
/*!40000 ALTER TABLE `vn_danhgia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_gallery_menu`
--

DROP TABLE IF EXISTS `vn_gallery_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_gallery_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `hinh` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `post_type` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_gallery_menu`
--

LOCK TABLES `vn_gallery_menu` WRITE;
/*!40000 ALTER TABLE `vn_gallery_menu` DISABLE KEYS */;
INSERT INTO `vn_gallery_menu` VALUES (1,'2',1,1,'no','catgal'),(2,'2',2,1,'no','catgal'),(3,'7',1,1,'no','catgal'),(4,'7',2,1,'no','catgal'),(5,'7',3,1,'no','catgal');
/*!40000 ALTER TABLE `vn_gallery_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_gallery_menu_lang`
--

DROP TABLE IF EXISTS `vn_gallery_menu_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_gallery_menu_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_menu_id` int(11) NOT NULL,
  `lang_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_thich` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_gallery_menu_lang`
--

LOCK TABLES `vn_gallery_menu_lang` WRITE;
/*!40000 ALTER TABLE `vn_gallery_menu_lang` DISABLE KEYS */;
INSERT INTO `vn_gallery_menu_lang` VALUES (1,1,'vn','Slide Trang Chá»§','','slide-trang-chu'),(2,2,'vn','Banner quáº£ng cÃ¡o bÃªn pháº£i (trang chá»§)','','banner-quang-cao-ben-phai-(trang-chu)'),(3,3,'vn','ThÆ° viá»‡n 1','','thu-vien-1'),(4,4,'vn','ThÆ° viá»‡n 2','','thu-vien-2'),(5,5,'vn','ThÆ° viá»‡n 3','','thu-vien-3');
/*!40000 ALTER TABLE `vn_gallery_menu_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_menu`
--

DROP TABLE IF EXISTS `vn_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_menu` (
  `menu_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cat` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `post_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `menu_cat` int(1) NOT NULL,
  `type_link` int(1) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_menu`
--

LOCK TABLES `vn_menu` WRITE;
/*!40000 ALTER TABLE `vn_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `vn_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_online`
--

DROP TABLE IF EXISTS `vn_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_online` (
  `ip` varchar(255) NOT NULL DEFAULT '',
  `time` varchar(255) NOT NULL DEFAULT '',
  `site` varchar(255) NOT NULL DEFAULT '',
  `agent` varchar(255) NOT NULL DEFAULT '',
  `user` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_online`
--

LOCK TABLES `vn_online` WRITE;
/*!40000 ALTER TABLE `vn_online` DISABLE KEYS */;
INSERT INTO `vn_online` VALUES ('66.249.93.42','1527329671','','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon',0);
/*!40000 ALTER TABLE `vn_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_online_daily`
--

DROP TABLE IF EXISTS `vn_online_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_online_daily` (
  `ngay` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `bo_dem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_online_daily`
--

LOCK TABLES `vn_online_daily` WRITE;
/*!40000 ALTER TABLE `vn_online_daily` DISABLE KEYS */;
INSERT INTO `vn_online_daily` VALUES ('28/08/2017',43),('29/08/2017',16),('30/08/2017',9),('31/08/2017',17),('05/09/2017',8),('06/09/2017',22),('07/09/2017',16),('08/09/2017',11),('09/09/2017',3),('11/09/2017',5),('12/09/2017',8),('14/09/2017',10),('15/09/2017',22),('17/09/2017',14),('18/09/2017',34),('19/09/2017',15),('20/09/2017',2),('21/09/2017',6),('22/09/2017',10),('24/09/2017',5),('25/09/2017',16),('26/09/2017',25),('27/09/2017',20),('28/09/2017',12),('29/09/2017',20),('11/10/2017',19),('12/10/2017',27),('13/10/2017',26),('14/10/2017',27),('16/10/2017',24),('17/10/2017',30),('18/10/2017',8),('24/10/2017',12),('25/10/2017',40),('26/10/2017',51),('27/10/2017',9),('30/10/2017',20),('31/10/2017',36),('01/11/2017',26),('02/11/2017',42),('03/11/2017',15),('04/11/2017',1),('06/11/2017',16),('07/11/2017',31),('08/11/2017',12),('09/11/2017',36),('10/11/2017',10),('11/11/2017',14),('12/11/2017',20),('13/11/2017',23),('22/11/2017',4),('23/11/2017',3),('24/11/2017',39),('25/11/2017',10),('30/11/2017',1),('02/12/2017',1),('06/12/2017',22),('07/12/2017',16),('08/12/2017',19),('10/12/2017',2),('11/12/2017',19),('12/12/2017',11),('06/03/2018',36),('07/03/2018',119),('08/03/2018',38),('09/03/2018',79),('10/03/2018',39),('11/03/2018',20),('12/03/2018',54),('13/03/2018',56),('14/03/2018',37),('15/03/2018',45),('16/03/2018',35),('17/03/2018',30),('18/03/2018',32),('19/03/2018',52),('20/03/2018',49),('21/03/2018',97),('22/03/2018',54),('23/03/2018',29),('24/03/2018',44),('25/03/2018',8),('26/03/2018',45),('27/03/2018',23),('28/03/2018',57),('29/03/2018',23),('30/03/2018',27),('31/03/2018',6),('01/04/2018',10),('02/04/2018',5),('03/04/2018',12),('04/04/2018',11),('05/04/2018',4),('06/04/2018',9),('07/04/2018',1),('08/04/2018',6),('09/04/2018',8),('10/04/2018',5),('11/04/2018',6),('12/04/2018',2),('13/04/2018',5),('14/04/2018',6),('15/04/2018',4),('16/04/2018',7),('17/04/2018',3),('18/04/2018',2),('19/04/2018',9),('20/04/2018',9),('21/04/2018',4),('22/04/2018',4),('23/04/2018',1),('24/04/2018',8),('25/04/2018',4),('26/04/2018',3),('27/04/2018',11),('28/04/2018',7),('29/04/2018',2),('30/04/2018',6),('01/05/2018',7),('02/05/2018',3),('04/05/2018',6),('05/05/2018',2),('06/05/2018',3),('07/05/2018',3),('08/05/2018',7),('09/05/2018',7),('10/05/2018',7),('11/05/2018',2),('12/05/2018',3),('13/05/2018',19),('14/05/2018',15),('15/05/2018',2),('16/05/2018',6),('17/05/2018',15),('18/05/2018',15),('19/05/2018',5),('20/05/2018',3),('21/05/2018',6),('22/05/2018',6),('23/05/2018',5),('24/05/2018',4),('25/05/2018',5),('26/05/2018',2);
/*!40000 ALTER TABLE `vn_online_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_page`
--

DROP TABLE IF EXISTS `vn_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `luot_xem` int(11) DEFAULT '1',
  `option1` int(11) NOT NULL,
  `post_type` varchar(50) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `alias` varchar(100) NOT NULL,
  `home` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_page`
--

LOCK TABLES `vn_page` WRITE;
/*!40000 ALTER TABLE `vn_page` DISABLE KEYS */;
INSERT INTO `vn_page` VALUES (1,1526506732,5,1,0,'page_none',1,'',1),(2,1522226372,5,1,0,'',1,'info_about',0),(13,1512626909,5,1,0,'',1,'phuong_thuc',0),(4,1512528893,5,18,0,'about_us',1,'',0),(5,1512528878,5,8,0,'about_us',1,'',0),(6,1512528850,5,1,0,'about_us',1,'',0),(7,1512718565,5,1,0,'bao_hanh',1,'',0),(8,1512529247,5,1,0,'danhsach_dl',1,'',0),(9,1512529540,5,1,0,'form_dk',1,'',0),(10,1512529626,5,1,0,'thanh_toan',1,'',0),(11,1512529834,5,1,1,'contact',1,'',0),(12,1512529865,5,1,0,'contact',1,'',0),(14,1512965620,5,1,1,'sp',1,'',0),(15,1513047407,5,1,0,'cart',1,'',0),(16,1513050826,5,1,0,'order',1,'',0),(17,1522227739,5,1,0,'',1,'tien_mat',0),(18,1522227827,5,1,0,'',1,'chuyen_khoan_atm',0),(19,1521615516,5,1,0,'',1,'qc',0),(20,1521604103,5,1,0,'chinh_sach',1,'',0);
/*!40000 ALTER TABLE `vn_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_page_lang`
--

DROP TABLE IF EXISTS `vn_page_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_page_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `lang_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chu_thich` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title_seo` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_page_lang`
--

LOCK TABLES `vn_page_lang` WRITE;
/*!40000 ALTER TABLE `vn_page_lang` DISABLE KEYS */;
INSERT INTO `vn_page_lang` VALUES (1,1,'vn','Trang chá»§','','','<p>Trang n&agrave;y ráº¥t hay</p>\r\n','','','','trang-chu.html'),(2,2,'vn','Giá»›i thiá»‡u','','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n','','','',''),(22,13,'vn','PhÆ°Æ¡ng thá»©c thanh toÃ¡n','','','<p>&nbsp;<img alt=\"\" src=\"/uploads/images/images/pt1.png\" style=\"float: left; width: 119px; height: 47px; margin-left: 2px; margin-right: 2px;\" /><img alt=\"\" src=\"/uploads/images/images/pt2.png\" style=\"float: left; width: 137px; height: 51px;\" /></p>\r\n','','','',''),(4,4,'vn','Vá» chÃºng tÃ´i','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','ve-chung-toi.html'),(5,5,'vn','ThÃ´ng tin vÃ  sá»© má»‡nh cÃ´ng ty','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','thong-tin-va-su-menh-cong-ty.html'),(6,6,'vn','VÄƒn hÃ³a truyá»n thá»‘ng hoáº¡t Ä‘á»™ng cÃ´ng ty','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','van-hoa-truyen-thong-hoat-dong-cong-ty.html'),(7,6,'en','Traditional culture operating company','','','','','','','traditional-culture-operating-company.html'),(8,5,'en','Information and corporate mission','','','','','','','information-and-corporate-mission.html'),(9,4,'en','About us','','','','','','','about-us.html'),(10,7,'vn','Cháº¿ Ä‘á»™ báº£o hÃ nh','','','<p align=\"justify\">Lorem ipsum dolor sit amet, tempus dolor mattis turpis blandit turpis per, non tellus pellentesque vitae sed ut, amet quis facilisi consectetuer arcu in sed, lorem tempor praesent eget scelerisque vel rhoncus, wisi neque ultricies at quam. Posuere pulvinar wisi facilisis montes diam, orci diam quis in, risus sit lectus tellus aut, hac sodales eros suspendisse wisi id, placerat amet luctus nibh mus posuere. Mi dui id volutpat fermentum duis, nulla justo pellentesque ullamcorper lorem condimentum. Mollis pulvinar neque nec bibendum. Pretium etiam amet eu tristique sed, metus eligendi hac elementum non pede scelerisque, auctor posuere sem non non vel nullam, malesuada proin risus quam hymenaeos orci. Est malesuada ligula congue curabitur vestibulum diam, aliquam erat sed, euismod nunc elementum. Sit sed erat felis, vitae pellentesque id orci.</p>\r\n\r\n<p align=\"justify\">Lacus sem vehicula, lobortis commodo, quam quis, dui dui sed metus sit, in venenatis semper. Dictum neque elit fusce, gravida aliquam, aliquam nisl imperdiet augue nec. Parturient interdum amet amet felis wisi quis, velit ligula pellentesque pretium in ac, eu eleifend lacus hac, mattis cursus. Sed torquent lacus, tellus suspendisse libero suspendisse diam nullam. Ac congue, urna nullam ligula proin metus sodales, cum in mauris suspendisse fermentum porta, sit in pede et gravida eu, et venenatis etiam sollicitudin.</p>\r\n\r\n<p align=\"justify\">Lorem feugiat nullam dictumst diam mus. A a ac, ante arcu ad, eleifend sed sodales fusce ridiculus habitant fermentum, per incidunt malesuada montes vehicula risus, mauris elementum suspendisse. Sem pulvinar et placerat non, elit sit pede elit, in gravida ante molestie augue aliquam vehicula, magnis eget sapien laoreet. Mauris turpis vehicula, molestie tellus, vel libero diam vestibulum risus ultrices eget, euismod adipiscing cursus, eu sociosqu nunc pellentesque donec volutpat nullam. Vitae sed wisi, et elit ipsum nibh elit quam, vestibulum praesent molestiae odio dictum lobortis, suscipit porttitor lacus curabitur donec eget. Nibh eu, at lacinia eleifend, fringilla vestibulum, feugiat ut quis ligula, integer suscipit pellentesque dignissim arcu.</p>\r\n','','','','che-do-bao-hanh.html'),(11,7,'en','Warranty','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','warranty.html'),(12,8,'vn','Danh sÃ¡ch thÃ´ng tin Ä‘áº¡i lÃ½','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','danh-sach-thong-tin-dai-ly.html'),(13,9,'vn','Trá»Ÿ thÃ nh nhÃ  Ä‘áº¡i lÃ½','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','tro-thanh-nha-dai-ly.html'),(14,9,'en','Become an agent','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','become-an-agent.html'),(15,10,'vn','Thanh toÃ¡n trá»±c tuyáº¿n','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','thanh-toan-truc-tuyen.html'),(16,10,'en','Online payment','','','<p align=\"justify\">Lorem ipsum dolor sit amet, ea eros, mattis parturient tempor, non ullamcorper suspendisse nisl, eros alias pharetra placerat suscipit fermentum pede. Sapien eu sit ut risus in tincidunt, vitae a, tincidunt arcu consectetuer eros magna cursus consectetuer, sodales cras duis pellentesque vivamus. Libero eros donec nunc, minim lacus, et tellus aliquam integer sed bibendum adipiscing, placerat ac ut adipiscing in vestibulum. Molestie consequat augue scelerisque inceptos venenatis velit, cursus et feugiat risus. Nullam wisi, id odio congue quam, vestibulum donec vitae non dolor eu ligula. Integer integer eros, bibendum tellus vivamus metus dis ut mi, vestibulum nonummy ac. Quis urna sit metus curabitur, aenean venenatis, varius ut, venenatis purus vel eu, magna conubia. Lacinia ante neque ut phasellus, varius consectetuer, turpis odio dis magna. Vehicula volutpat, erat ipsum lectus aliquet purus. Sed sollicitudin laoreet.</p>\r\n\r\n<p align=\"justify\">Fermentum cursus ipsum, integer pellentesque neque, scelerisque erat non nulla posuere laoreet massa. Donec sit, odio ipsum. Suspendisse rhoncus etiam suscipit blandit, condimentum neque fermentum luctus enim. Est mauris pede diam et nibh, cursus dui sodales et fusce mauris volutpat, sed urna suspendisse wisi mollis consectetuer eros, luctus mollis iaculis, purus omnis adipiscing faucibus urna tempus. Elit curabitur lectus massa habitant magna tincidunt, augue malesuada, dui porttitor sit vestibulum, laboris amet in ut faucibus leo, tellus arcu wisi lectus neque. Augue in est lorem pede convallis diam. Est sem pulvinar pulvinar.</p>\r\n','','','','online-payment.html'),(17,11,'vn','LiÃªn há»‡','','','','','','','lien-he.html'),(18,11,'en','Contact us','','','','','','','contact-us.html'),(19,12,'vn','ThÃ´ng tin liÃªn há»‡','','','','','','','thong-tin-lien-he.html'),(20,12,'en','Contact us','','','','','','','contact-us-p12.html'),(21,2,'en','DAESA','','','','','','',''),(23,13,'en','Payment methods','','','','','','',''),(24,14,'vn','Sáº£n pháº©m','','','','','','','san-pham.html'),(25,14,'en','Products','','','','','','','products.html'),(26,15,'vn','Giá» hÃ ng','','','','','','','gio-hang.html'),(27,15,'en','cart','','','','','','','cart.html'),(28,16,'vn','Äáº·t hÃ ng','','','','','','','dat-hang.html'),(29,16,'en','Order','','','','','','','order.html'),(30,17,'vn','Tiá»n máº·t','','','<p>Giao h&agrave;ng v&agrave; thu tiá»n táº¡i nh&agrave;.</p>\r\n\r\n<p>Hotline: 0979041002</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n','','','',''),(31,18,'vn','Chuyá»ƒn khoáº£n qua ngÃ¢n hÃ ng','','','<p>1/ Ng&acirc;n h&agrave;ng Ä&ocirc;ng &Aacute; - Ä&agrave; Náºµng</p>\r\n\r\n<p>S&ocirc; tk: -----</p>\r\n\r\n<p>Chá»§ tk: -------</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>===</p>\r\n\r\n<p>2/ Ng&acirc;n h&agrave;ng VCB - Ä&agrave; Náºµng</p>\r\n\r\n<p>...</p>\r\n','','','',''),(32,18,'en','Transfer via bank','','','','','','',''),(33,17,'en','Cash','','','','','','',''),(34,19,'vn','Banner quáº£ng cÃ¡o','http://myphamdaesa.com/','','','','','',''),(35,19,'en','av Banner ','','','','','','',''),(36,20,'vn','ChÃ­nh sÃ¡ch Ä‘áº¡i lÃ½','','','','','','','chinh-sach-dai-ly.html'),(37,20,'en','Agency policy','','','','','','','agency-policy.html');
/*!40000 ALTER TABLE `vn_page_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_support`
--

DROP TABLE IF EXISTS `vn_support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tieude` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hinh` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `yahoo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `skype` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `facebook` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tel` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `luot_xem` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tieude` (`tieude`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_support`
--

LOCK TABLES `vn_support` WRITE;
/*!40000 ALTER TABLE `vn_support` DISABLE KEYS */;
/*!40000 ALTER TABLE `vn_support` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_thanh_vien`
--

DROP TABLE IF EXISTS `vn_thanh_vien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_thanh_vien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dien_thoai` varchar(255) NOT NULL,
  `dia_chi` varchar(255) NOT NULL,
  `trang_thai` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `yahoo` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `ngay` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_thanh_vien`
--

LOCK TABLES `vn_thanh_vien` WRITE;
/*!40000 ALTER TABLE `vn_thanh_vien` DISABLE KEYS */;
/*!40000 ALTER TABLE `vn_thanh_vien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vn_user`
--

DROP TABLE IF EXISTS `vn_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vn_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'no',
  `ten` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dien_thoai` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dia_chi` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` int(1) DEFAULT '0',
  `trang_thai` int(1) NOT NULL DEFAULT '0',
  `images` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `dir` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vn_user`
--

LOCK TABLES `vn_user` WRITE;
/*!40000 ALTER TABLE `vn_user` DISABLE KEYS */;
INSERT INTO `vn_user` VALUES (5,'coder','71e87eebdd14f5d89db40cba650f9d2a','BÃ¹i quang tÃ­n','buiquangtinit@gmail.com','0972696904','ÄÃ  Náºµng',0,1,'5-coder.jpg',1466390221,'member/'),(4,'admin','a5361f70d2a1b76438d0fa4fd74e679c','admin','admin@gmai.com','09999999999','ÄÃ  Náºµng',1,1,'4-admin.jpg',1465871477,'member/'),(7,'nguyen','9ba01d45bf2e7d12b4ec8c56396b5efe','Long VinaDesign','longcaodn@gmail.com','0943426600','ÄÃ  Náºµng',1,1,'',1522226536,'');
/*!40000 ALTER TABLE `vn_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-26 18:03:04
