<div class="img_top">
    <?=get_single_image("13","post","avatar")?>
</div>
<div class="container">
    
    <div class="margin-top30 other_box">
        <h1 class="content--title1" style="margin-top: 0"><?=the_title?></h1>
        <div class="noi_dung">
            <?=the_content?>
        </div>
        <div style="padding: 20px 0;text-align: center;"><a class="dk_dl" href="<?=$root?>/<?=show_infopage("contact","slug","11")?>"><?=$translate['Đăng ký trở thành đại lý'][$lang_code]?></a></div>
    </div>
</div>