<div class="img_top">
    <?=get_single_image("38","post","avatar")?>
</div>
<div class="container">
    
    <div class="margin-top30 other_box">
        <h1 class="content--title1" style="margin-top: 0"><?=the_title?></h1>
        <div class="noi_dung">
            <?=the_content?>
        </div>
    </div>
</div>