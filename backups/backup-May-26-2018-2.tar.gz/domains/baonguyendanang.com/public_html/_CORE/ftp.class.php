<?
class	lg_ftp
{
	public	function	__construct()
	{	
	}
	public	function	__destruct()
	{	
	}
}
?>